<?php
require_once 'Conexion.php';
class Valores{

    private $codRegistro;
    private $temperatura;
    private $humedad;
    private $fecha;

    const table="tb_valores";

    /**
     * @return mixed
     */
    public function getCodRegistro()
    {
        return $this->codRegistro;
    }

    /**
     * @param mixed $codRegistro
     */
    public function setCodRegistro($codRegistro)
    {
        $this->codRegistro = $codRegistro;
    }

    /**
     * @return mixed
     */
    public function getTemperatura()
    {
        return $this->temperatura;
    }

    /**
     * @param mixed $temperatura
     */
    public function setTemperatura($temperatura)
    {
        $this->temperatura = $temperatura;
    }

    /**
     * @return mixed
     */
    public function getHumedad()
    {
        return $this->humedad;
    }

    /**
     * @param mixed $humedad
     */
    public function setHumedad($humedad)
    {
        $this->humedad = $humedad;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;
    }

    public function insModValores(){
        try{
            $retorno=array();
            $conexion=new Conexion();
            $consulta=$conexion->prepare("call sp_insmod_valores(:codRegistros,:temperatura,:humedad)");
            $consulta->bindValue(":codRegistros",$this->getCodRegistro(),PDO::PARAM_INT);
            $consulta->bindValue(":temperatura",$this->getTemperatura(),PDO::PARAM_STR);
            $consulta->bindValue(':humedad',$this->getHumedad(),PDO::PARAM_STR);

            $consulta->execute();
            $retorno=$consulta->fetch(PDO::FETCH_ASSOC);

        }catch(PDOException $ex){
            echo "Ocurrió un error :".$ex->getMessage();
        }finally{
            $conexion=null;
            echo json_encode($retorno);
        }

    }

}