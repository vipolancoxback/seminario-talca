<?php

class Conexion extends PDO {
    private $host="localhost";
    private $tipo_de_bd = 'mysql';
    private $nombre_de_bd = '';
    private $usuario="";
    private $clave=";";


    public function __construct() {
        //Sobreescribo el método constructor de la clase PDO.
        try{
            parent::__construct($this->tipo_de_bd.':host='.$this->host.';dbname='.$this->nombre_de_bd,
                $this->usuario, $this->clave, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
        }catch(PDOException $e){
            echo 'Ha surgido un error y no se puede conectar a la base de datos. Detalle: ' . $e->getMessage();
            exit;
        }
    }

}

?>