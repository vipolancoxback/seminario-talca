<?php

class Action {
    private $action;
    private $arregloValores;

    public function __construct(){
        $this->arregloValores=array("insertarModificarValores");
    }

    /**
     * @return mixed
     */
    public function getAction()
    {
        return $this->action;
    }

    /**
     * @param mixed $action
     */
    public function setAction($action)
    {
        $this->action = $action;
    }

    /**
     * @return array
     */
    public function getArregloValores()
    {
        return $this->arregloValores;
    }

    /**
     * @param array $arregloValores
     */
    public function setArregloValores($arregloValores)
    {
        $this->arregloValores = $arregloValores;
    }


}