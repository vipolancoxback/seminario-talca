<?php
require_once 'Action.php';
if(isset($_REQUEST['action'])){
    $action=(isset($_REQUEST['action'])?$_REQUEST['action']:NULL);
    $action=filter_var($action,FILTER_SANITIZE_STRING);

    $general=new Action();
    $general->setAction($action);
    if(in_array($general->getAction(),$general->getArregloValores())){
        require_once '../../models/Valores.php';
        switch($general->getAction()){
            case 'insertarModificarValores':
                $codRegistro=(isset($_REQUEST['codRegistros'])?$_REQUEST['codRegistros']:NULL);

                $humedad=(isset($_REQUEST['humedad'])?$_REQUEST['humedad']:NULL);
                $humedad=filter_var($humedad,FILTER_SANITIZE_NUMBER_FLOAT);

                $temperatura=(isset($_REQUEST['temperatura'])?$_REQUEST['temperatura']:NULL);
                $temperatura=filter_var($temperatura,FILTER_SANITIZE_NUMBER_FLOAT);

                $va=new Valores();
                $va->setCodRegistro($codRegistro);
                $va->setHumedad($humedad);
                $va->setTemperatura($temperatura);

                echo $va->insModValores();
        }

    }
}